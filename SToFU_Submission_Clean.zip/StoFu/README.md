# SToFU Systems — C++ / WinAPI Practical Assignment

## Project overview

This submission demonstrates a WinAPI `MessageBoxW` hook using the **SToFU Systems development branch of Mhook**, and a one-byte modification to the compiled executable analyzed using Ghidra and edited using HxD.

- `Test_task/main.cpp` — original submitted C++ source, **preserved unchanged**.
- `Test_task/Test_task.sln` — Visual Studio 2022 solution.
- `Test_task/Test_task.vcxproj` — Visual Studio project. Its two Mhook search paths were changed from machine-specific absolute paths to paths relative to the solution.
- `mhook-development/` — Mhook source code and a locally built **x64 Debug** static library, `mhook.lib` (MIT-licensed; see its LICENSE file).
- `ReverseEngineering/Test_task_original.exe` — original Windows x64 Debug executable.
- `ReverseEngineering/Test_task_patched.exe` — executable after a one-byte HEX patch.

## Build (Windows, Visual Studio 2022)

1. Extract the whole ZIP with the folder layout unchanged.
2. Open `Test_task/Test_task.sln` in Visual Studio 2022.
3. Select **Debug | x64**. This is the tested configuration; other configurations do not have Mhook library paths configured.
4. Build and run the application. The provided `mhook.lib` and headers are under `mhook-development/_install/x64/debug/`, referenced by relative project paths.
5. Alternatively, recompile the Mhook dependency: open a Visual Studio Developer Command Prompt, change to `mhook-development`, and run `setup.bat --build x64-debug`. This requires CMake, Python, and the MSVC C++ toolchain. The resulting library is installed under `_install/x64/debug/`.

**Important:** The C++ source is deliberately preserved as supplied in the original archive, including an initial fixed `testNumber = 4` test dialog followed by the actual randomized loop. Rebuilding the application produces an **unpatched** executable. Do not mistake a rebuilt EXE for the supplied patched binary. The compiled EXEs in `ReverseEngineering/` are the reverse-engineering test artifacts; they are not generated on the fly.

## Expected behavior

In the original executable:

- Number 1 displays as 100 via the Mhook detour.
- Number 2 calls `std::abort()` and terminates abnormally.
- Numbers 3–20 display normally.

In the provided patched executable:

- Number 1 still displays as 100.
- Number 2 displays normally without executing `abort()`.
- Numbers 3–20 display normally.

Use the buttons in the message dialog to continue or exit. The program runs on Windows x64. These executables have not been run in the environment used to prepare this ZIP; the user's Windows test confirmed the patched binary continued normally.

## Binary patch

See [PATCH_NOTES.md](PATCH_NOTES.md) for exact offsets and opcode explanation. The original and patched EXEs differ by **one byte only**.

## Ghidra / MCP

The binary was analyzed in Ghidra 12.1.3; a locally installed GhidraMCP plugin responded to `curl http://127.0.0.1:8089/check_connection`. The MCP plugin and AI client environment are not embedded in this archive. The original personal Ghidra project database is intentionally omitted because the executables can be imported and analyzed anew.

## Video

**Not included.** The assignment asks for a recording of the full solution process, including AI prompts. Provide the recording or a separate video link as part of the actual submission.

## Third-party software

Mhook source: https://github.com/SToFU-Systems/mhook/tree/development  
Mhook copyright and MIT license: `mhook-development/LICENSE`.
