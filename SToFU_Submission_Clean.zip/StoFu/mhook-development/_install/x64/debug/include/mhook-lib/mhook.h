//================================================================================
//    /$$      /$$ /$$   /$$                     /$$
//   | $$$    /$$$| $$  | $$                    | $$
//   | $$$$  /$$$$| $$  | $$  /$$$$$$   /$$$$$$ | $$   /$$
//   | $$ $$/$$ $$| $$$$$$$$ /$$__  $$ /$$__  $$| $$  /$$/
//   | $$  $$$| $$| $$__  $$| $$  \ $$| $$  \ $$| $$$$$$/
//   | $$\  $ | $$| $$  | $$| $$  | $$| $$  | $$| $$_  $$
//   | $$ \/  | $$| $$  | $$|  $$$$$$/|  $$$$$$/| $$ \  $$
//   |__/     |__/|__/  |__/ \______/  \______/ |__/  \__/
//
// Modifications and original additions:
// Copyright (c) 2026, SToFU Systems (https://stofu.io). All rights reserved.
//
// Licensed under the MIT License.
// See LICENSE in the repository root for the full license text.
//
// Original author:
//
// Copyright (c) 2007-2008, Marton Anka
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//================================================================================

#pragma once

#include <windows.h>

// Pulled in here so that including the public header is enough to get the
// version macros; a consumer should not have to know a second header exists.
#include <mhook-lib/version.h>

#ifdef __cplusplus
extern "C"
{
#endif //__cplusplus

/**
 * @brief Identifies the detailed result of a hook operation.
 *
 * Mhook_SetHook(), Mhook_Unhook(), their batch forms, and
 * Mhook_ReclaimRetired() store one of these values for the calling thread. The
 * value describes the first detected internal failure unless a later failure
 * determines that the operation itself cannot complete.
 * MHOOK_STATUS_THREAD_RESUME_FAILED is the one status that can accompany a
 * successful operation.
 *
 */
typedef enum MHOOK_STATUS
{
    /** No monitored operation reported a failure. */
    MHOOK_STATUS_SUCCESS = 0,

    /** A required address is NULL, resolved functions are identical, or a removal is repeated in one batch. */
    MHOOK_STATUS_INVALID_ARGUMENT = 1,

    /** The target prologue could not be decoded. */
    MHOOK_STATUS_DECODE_FAILED = 2,

    /** The decoded prologue cannot hold a supported patch. */
    MHOOK_STATUS_UNSUPPORTED_PROLOGUE = 3,

    /** No suitable trampoline could be allocated. */
    MHOOK_STATUS_TRAMPOLINE_ALLOCATION_FAILED = 4,

    /** A required memory-protection change failed. */
    MHOOK_STATUS_MEMORY_PROTECTION_FAILED = 5,

    /** The supplied trampoline does not identify an active hook. */
    MHOOK_STATUS_HOOK_NOT_FOUND = 6,

    /** A peer thread could not be suspended or inspected, or the suspended-thread list could not grow. */
    MHOOK_STATUS_THREAD_SUSPENSION_FAILED = 7,

    /** An instruction-cache flush for modified code failed. */
    MHOOK_STATUS_PATCH_FAILED = 8,

    /** Live target bytes no longer match the image retained by Mhook. */
    MHOOK_STATUS_TARGET_MODIFIED = 9,

    /** The caller's function-pointer slot is misaligned, unreadable, or unwritable. */
    MHOOK_STATUS_INVALID_DESCRIPTOR = 10,

    /** Executable code or an indirect jump's pointer slot cannot be read. */
    MHOOK_STATUS_INVALID_TARGET = 11,

    /** Following entry-point jumps encountered an address already visited. */
    MHOOK_STATUS_JUMP_CYCLE = 12,

    /** Following entry-point jumps exceeded the supported depth. */
    MHOOK_STATUS_JUMP_DEPTH_EXCEEDED = 13,

    /** A resolved request conflicts with an active hook or another batch entry. */
    MHOOK_STATUS_ALREADY_HOOKED = 14,

    /** The process's threads could not be listed. */
    MHOOK_STATUS_THREAD_ENUMERATION_FAILED = 15,

    /** A peer thread refused the suspend, resume, and get-context rights Mhook needs. */
    MHOOK_STATUS_THREAD_ACCESS_DENIED = 16,

    /**
     * A peer kept executing the code being patched or freed, was still exiting, or new threads kept
     * starting. Nothing was changed, and the operation may succeed if retried.
     */
    MHOOK_STATUS_THREAD_BUSY = 17,

    /**
     * A suspended peer could not be resumed and may stay suspended. Reported over any other
     * status, including after an operation that completed and returned TRUE.
     */
    MHOOK_STATUS_THREAD_RESUME_FAILED = 18
} MHOOK_STATUS;

/**
 * @brief Carries one hook request and its result through batch operations.
 *
 * Both batch APIs update the caller-owned function slot, so the same descriptor
 * array can install and later remove its hooks without being rebuilt.
 */
typedef struct MHOOK_HOOK_INFO
{
    /** Caller-owned slot that receives the trampoline or restored target. */
    PVOID* ppSystemFunction;

    /** Replacement used for installation and ignored during removal. */
    PVOID pHookFunction;

    /** Result written for this request by the most recent batch operation. */
    MHOOK_STATUS status;
} MHOOK_HOOK_INFO;

/**
 * @brief Describes the trampoline pool at one moment.
 *
 * Every trampoline occupies one code slot in a pool block. A slot is free,
 * active (its hook is installed), retired (its hook was removed, but its code
 * stays valid until Mhook_ReclaimRetired() frees it), or stranded (a failed
 * installation could not restore its target, so the slot is kept for good).
 */
typedef struct MHOOK_POOL_STATISTICS
{
    /** Slots backing installed hooks. */
    SIZE_T activeTrampolines;

    /** Slots of removed hooks, waiting for Mhook_ReclaimRetired(). */
    SIZE_T retiredTrampolines;

    /** Slots kept because a failed installation could not restore its target. */
    SIZE_T strandedTrampolines;

    /** Unused slots in allocated blocks. */
    SIZE_T freeTrampolines;

    /** Pool blocks currently allocated. */
    SIZE_T blockCount;

    /** Bytes of address space held by pool blocks. */
    SIZE_T reservedBytes;
} MHOOK_POOL_STATISTICS;

/**
 * @name Error codes reported through GetLastError()
 * The values sit in the range Windows reserves for application defined codes.
 * @{
 */

/** The pointer does not name a hook that is currently installed. */
#define MHOOK_ERROR_NOT_HOOKED ((DWORD)((1UL << 29) | 1UL))

/** Another writer has patched the target since. See Mhook_Unhook(). */
#define MHOOK_ERROR_TARGET_MODIFIED ((DWORD)((1UL << 29) | 2UL))

/** @} */

/**
 * @brief Installs a hook, redirecting a function to a replacement.
 *
 * Both addresses are followed through up to 16 jump thunks first, so hooking
 * an import stub hooks the function behind it. Longer or cyclic chains are
 * rejected. Requests are also rejected when both chains resolve to the same
 * address or either chain reaches a target with an active hook.
 *
 * @param[in,out] ppSystemFunction On entry the function to hook. On success,
 *        receives the trampoline: call it to reach the original, and pass it to
 *        Mhook_Unhook() and Mhook_GetTarget(). Unchanged on failure.
 * @param[in]     pHookFunction    Replacement, with the same calling convention
 *        and signature as the target.
 * @return TRUE if the hook was installed. The caller's GetLastError value is
 *         preserved on both success and failure.
 *
 * @note Fails if the prologue does not decode into at least five bytes of whole
 *       instructions. Retrieve failure details with Mhook_GetLastStatus().
 */
BOOL Mhook_SetHook(PVOID* ppSystemFunction, PVOID pHookFunction);


/**
 * @brief Atomically installs a batch of hook requests.
 *
 * Every request is resolved, decoded, checked for conflicts, and assigned a
 * trampoline before any target is modified. The batch then installs every
 * patch while peer threads are suspended. A later commit failure restores all
 * earlier patches, leaving caller slots and the active-hook registry unchanged.
 *
 * A SUCCESS entry in a failed batch means that request was valid and did not
 * cause the failure; it was not published. The failing entry carries the
 * diagnostic status, which is also returned by Mhook_GetLastStatus().
 *
 * @param[in,out] hooks Requests to install and storage for their results.
 * @param[in]     hookCount Number of descriptors in hooks.
 * @return TRUE when every hook was installed; otherwise FALSE.
 */
BOOL Mhook_SetHookBatch(MHOOK_HOOK_INFO* hooks, SIZE_T hookCount);


/**
 * @brief Removes a hook and restores the bytes it overwrote.
 *
 * Restores only if the prologue still holds exactly the patch this hook
 * installed. Otherwise another writer has patched the same code since, and
 * nothing is written, so their work is not destroyed.
 *
 * The hook then stays installed, because Mhook holds the only copy of the
 * original bytes. Retry once the other writer puts Mhook's patch back, or leave
 * the hook in place. Mhook_GetTarget() names the contested address.
 *
 * @param[in,out] ppHookedFunction The trampoline from Mhook_SetHook(). On
 *        success receives the original function address; unchanged on any
 *        failure, so a refused call can be retried with the same pointer.
 * @return TRUE if the original bytes were restored. On success, the caller's
 *         GetLastError value is preserved.
 * @retval FALSE Invalid arguments, descriptors, and inaccessible targets
 *         preserve GetLastError. Otherwise it is MHOOK_ERROR_TARGET_MODIFIED,
 *         MHOOK_ERROR_NOT_HOOKED, or the code from the failed VirtualProtect.
 *
 * @warning The trampoline is retired, not freed: code that loaded it earlier
 *          may still call it and reach the original function. It is freed by
 *          Mhook_ReclaimRetired(), after which it must not be called or
 *          passed to any Mhook function.
 */
BOOL Mhook_Unhook(PVOID* ppHookedFunction);


/**
 * @brief Atomically removes a batch of hook requests.
 *
 * Every caller slot and installed patch is validated before any target is
 * modified. The batch then restores every target while peer threads are
 * suspended. A later removal failure reinstalls all earlier patches, leaving
 * caller slots and the active-hook registry unchanged.
 *
 * A SUCCESS entry in a failed batch means that request was valid and did not
 * cause the failure; it was not removed. The failing entry carries the
 * diagnostic status, which is also returned by Mhook_GetLastStatus().
 *
 * Removed trampolines are retired as with Mhook_Unhook(), and freed by
 * Mhook_ReclaimRetired().
 *
 * @param[in,out] hooks Requests to remove and storage for their results.
 *        pHookFunction is ignored.
 * @param[in]     hookCount Number of descriptors in hooks.
 * @return TRUE when every hook was removed; otherwise FALSE.
 */
BOOL Mhook_UnhookBatch(MHOOK_HOOK_INFO* hooks, SIZE_T hookCount);


/**
 * @brief Frees the trampolines of removed hooks and releases pool memory that
 *        no installed hook uses.
 *
 * A removed hook's trampoline stays valid after Mhook_Unhook(), because code
 * that loaded the trampoline pointer earlier may still call it. This call
 * frees every such retired trampoline at once, then releases each pool block
 * left without trampolines. Installed hooks are not affected. With no hooks
 * installed, it releases every block that holds no stranded trampoline.
 *
 * @warning The caller must guarantee that no thread will call any trampoline
 *          removed so far, including hook functions that are still running and
 *          may already have loaded one. Mhook checks only that no thread is
 *          executing inside a retired trampoline at this moment. Reclaimed
 *          trampoline addresses may be handed out again to later hooks, so
 *          stale copies must not be passed to any Mhook call.
 *
 * @return TRUE when every retired trampoline was freed. On success the
 *         caller's GetLastError value is preserved.
 * @retval FALSE Nothing was freed. Mhook_GetLastStatus() is
 *         MHOOK_STATUS_THREAD_BUSY when a thread was executing inside a retired
 *         trampoline, so a retry may succeed, or another thread coordination
 *         status. GetLastError describes the thread failure.
 */
BOOL Mhook_ReclaimRetired(void);


/**
 * @brief Reports which address an installed hook patched.
 *
 * The way to learn which address is contested after Mhook_Unhook() refuses.
 *
 * @param[in] pHookedFunction The trampoline from Mhook_SetHook().
 * @return The patched address, or NULL with MHOOK_ERROR_NOT_HOOKED if the
 *         pointer names no installed hook.
 *
 * @note This is the address after jump thunks were followed, not necessarily
 *       the one handed to Mhook_SetHook().
 */
PVOID Mhook_GetTarget(PVOID pHookedFunction);


/**
 * @brief Reports the current state of the trampoline pool.
 *
 * The counts are taken under the lock that serializes every hook operation,
 * so they describe one consistent moment and match the pool's real
 * allocations.
 *
 * @param[out] statistics Receives the counts.
 * @return TRUE on success. FALSE with ERROR_INVALID_PARAMETER when statistics
 *         is NULL.
 *
 * @note Unlike the set and unhook operations, this does not change the status
 *       Mhook_GetLastStatus() reports.
 */
BOOL Mhook_GetPoolStatistics(MHOOK_POOL_STATISTICS* statistics);


/**
 * @brief Returns the detailed status of the calling thread's most recent hook
 *        installation, removal, or reclaim.
 *
 * Each thread owns an independent status initialized to MHOOK_STATUS_SUCCESS.
 * Reading the value does not clear it. The next set, unhook, or reclaim
 * operation on the same thread replaces it, so callers that need a diagnostic
 * should retrieve it immediately after the operation. For a batch operation,
 * this reports the overall result; each descriptor reports its own result
 * through status.
 *
 * @return One of the MHOOK_STATUS values describing the latest operation on
 *         the calling thread.
 */
MHOOK_STATUS Mhook_GetLastStatus(void);


/**
 * @brief Returns the version of the library that is actually linked in.
 *
 * The MHOOK_VERSION_* macros describe the headers a caller compiled against.
 * This describes the binary those calls land in, which is the version that
 * matters when the library arrives prebuilt and the two can disagree.
 *
 * @return A static string of the form "3.0.0". The caller does not own it.
 */
const char* Mhook_GetVersion(void);

#ifdef __cplusplus
}
#endif //__cplusplus
