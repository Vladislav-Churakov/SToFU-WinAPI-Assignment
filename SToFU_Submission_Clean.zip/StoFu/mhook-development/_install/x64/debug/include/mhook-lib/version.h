//================================================================================
//    /$$      /$$ /$$   /$$                     /$$
//   | $$$    /$$$| $$  | $$                    | $$
//   | $$$$  /$$$$| $$  | $$  /$$$$$$   /$$$$$$ | $$   /$$
//   | $$ $$/$$ $$| $$$$$$$$ /$$__  $$ /$$__  $$| $$  /$$/
//   | $$  $$$| $$| $$__  $$| $$  \ $$| $$  \ $$| $$$$$$/
//   | $$\  $ | $$| $$  | $$| $$  | $$| $$  | $$| $$_  $$
//   | $$ \/  | $$| $$  | $$|  $$$$$$/|  $$$$$$/| $$ \  $$
//   |__/     |__/|__/  |__/ \______/  \______/ |__/  \__/
//
// Copyright (c) 2026, SToFU Systems (https://stofu.io). All rights reserved.
//
// Licensed under the MIT License.
// See LICENSE in the repository root for the full license text.
//================================================================================

#pragma once

/** Major version. Changes when the public interface breaks. */
#define MHOOK_VERSION_MAJOR 3

/** Minor version. Changes when the public interface grows compatibly. */
#define MHOOK_VERSION_MINOR 0

/** Patch version. Changes for fixes that do not touch the interface. */
#define MHOOK_VERSION_PATCH 0

/** Full version as a string literal, for example "3.0.0". */
#define MHOOK_VERSION_STRING "3.0.0"
